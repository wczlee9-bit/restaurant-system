#!/bin/bash

###############################################################################
# 快速部署脚本（从 GitHub）
# 作用：快速部署餐厅系统
# 使用：bash quick_deploy.sh
###############################################################################

set -e

echo "========================================"
echo "  餐厅系统快速部署（从 GitHub）"
echo "========================================"
echo ""

# 从 GitHub 克隆代码
echo "[1/4] 从 GitHub 克隆代码..."
git clone https://github.com/wczlee9-bit/restaurant-system.git
cd restaurant-system
echo "✅ 代码克隆完成"

# 创建虚拟环境
echo "[2/4] 创建虚拟环境..."
python3 -m venv venv
source venv/bin/activate
echo "✅ 虚拟环境创建完成"

# 安装依赖
echo "[3/4] 安装依赖..."
pip install --upgrade pip
pip install -r requirements.txt
echo "✅ 依赖安装完成"

# 测试模块
echo "[4/4] 测试模块..."
python test_module_loader.py
echo "✅ 模块测试完成"

# 启动服务
echo ""
echo "========================================"
echo "  准备启动服务..."
echo "========================================"
echo ""
echo "启动服务："
echo "  uvicorn src.main:app --host 0.0.0.0 --port 8000"
echo ""
echo "访问地址: http://$(hostname -I | awk '{print $1}'):8000"
echo ""
echo "按 Ctrl+C 停止服务"
