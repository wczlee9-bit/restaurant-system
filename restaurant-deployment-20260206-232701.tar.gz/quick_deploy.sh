#!/bin/bash

###############################################################################
# 快速部署脚本
# 作用：快速部署餐厅系统
# 使用：bash quick_deploy.sh
###############################################################################

set -e

echo "========================================"
echo "  餐厅系统快速部署"
echo "========================================"
echo ""

# 解压源代码
echo "[1/5] 解压源代码..."
if [ -f "source.tar.gz" ]; then
    tar -xzf source.tar.gz
    cd restaurant
    echo "✅ 源代码解压完成"
else
    echo "❌ 未找到 source.tar.gz"
    exit 1
fi

# 创建虚拟环境
echo "[2/5] 创建虚拟环境..."
python3 -m venv venv
source venv/bin/activate
echo "✅ 虚拟环境创建完成"

# 安装依赖
echo "[3/5] 安装依赖..."
pip install --upgrade pip
pip install -r requirements.txt
echo "✅ 依赖安装完成"

# 测试模块
echo "[4/5] 测试模块..."
python test_module_loader.py
echo "✅ 模块测试完成"

# 启动服务
echo "[5/5] 启动服务..."
uvicorn src.main:app --host 0.0.0.0 --port 8000 &
echo "✅ 服务启动完成"

echo ""
echo "========================================"
echo "  部署完成！"
echo "========================================"
echo ""
echo "访问地址: http://$(hostname -I | awk '{print $1}'):8000"
echo ""
echo "按 Ctrl+C 停止服务"
